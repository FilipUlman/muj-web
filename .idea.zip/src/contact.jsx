import React from "react";
import ContactForm from "./ContactForm";
function Contact() {
    return (
      <div className="content mx-4 my-4">
       
    <ContactForm />

    

      </div>
    );
  }
  
  export default Contact;